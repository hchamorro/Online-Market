module.exports = {
  Product: require("./product"),
  User: require("./user")
};
